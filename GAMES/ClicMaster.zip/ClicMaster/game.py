import pygame
import sys
import random
import time
import json
import os

# ------------------------
# Configuración Inicial
# ------------------------
pygame.init()
pygame.mixer.init()
ANCHO, ALTO = 1000, 700
screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption('Juego de Clics Profesional')
clock = pygame.time.Clock()
FPS = 60

# Función para cargar y cambiar el ícono de la ventana
def cambiar_icono():
    try:
        # Carga la imagen del ícono (asegúrate de tener la ruta correcta)
        icono = pygame.image.load('assets/logo.png')  # Cambia el nombre de archivo y ruta si es necesario
        pygame.display.set_icon(icono)
    except Exception as e:
        print(f"Error cargando el ícono: {e}")
        
# Llamar a la función para cambiar el ícono
cambiar_icono()

# ------------------------
# Colores y Fuentes
# ------------------------
COLORS = {
    'fondo': (50, 50, 50),
    'panel': (80, 80, 80),
    'texto': (200, 200, 200),
    'boton': (100, 100, 100),
    'boton_hover': (150, 150, 150),
    'comprar': (170, 170, 170)
}
try:
    fuente = pygame.font.Font('Roboto-Regular.ttf', 28)
    fuente_titulo = pygame.font.Font('Roboto-Regular.ttf', 42)
except:
    fuente = pygame.font.SysFont('Arial', 28)
    fuente_titulo = pygame.font.SysFont('Arial', 42)

# ------------------------
# Recursos
# ------------------------
def load_image(path, size=None):
    try:
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size) if size else img
    except Exception as e:
        print(f"Error cargando {path}: {e}")
        pygame.quit()
        sys.exit()

imagen = load_image('assets/una.png', (100, 100))
imagen_peq = pygame.transform.scale(imagen, (20, 20))

# ------------------------
# Sonido
# ------------------------
try:
    pygame.mixer.music.load("assets/musica_fondo.mp3")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

    sonido_clic = pygame.mixer.Sound("assets/clic.mp3")
    sonido_clic.set_volume(0.7)
except Exception as e:
    print("Error cargando sonidos:", e)
    sonido_clic = None

# ------------------------
# Variables de Juego
# ------------------------
gv = {
    'nivel': 1,
    'clics': 0,
    'umbral': 20,
    'monedas': 0,
    'shop': False,
    'missions': False,
    'stats': False,
    'autoclick': False,
    'last': time.time(),
    'particles': [],
    'extra_panel': False,
    'config': False,
    'music_volume': 0.5,
    'sound_volume': 0.7
}
MAX_PARTICLES = 100

# ------------------------
# Guardar/Cargar Juego
# ------------------------
# Definir la ruta de la carpeta 'Data'
data_folder = 'Data'
# Crear la carpeta si no existe
if not os.path.exists(data_folder):
    os.makedirs(data_folder)

def save_game_data():
    try:
        # Ruta completa para el archivo de datos
        file_path = os.path.join(data_folder, 'game_data.json')
        with open(file_path, 'w') as f:
            json.dump({
                'nivel': gv['nivel'],
                'clics': gv['clics'],
                'umbral': gv['umbral'],
                'monedas': gv['monedas']
            }, f)
        print("Datos guardados correctamente.")
    except Exception as e:
        print(f"Error guardando los datos: {e}")

def load_game_data():
    try:
        # Ruta completa para el archivo de datos
        file_path = os.path.join(data_folder, 'game_data.json')
        with open(file_path, 'r') as f:
            data = json.load(f)
            return data
    except FileNotFoundError:
        print("No se encontró el archivo de datos, creando uno nuevo.")
        return gv
    except Exception as e:
        print(f"Error cargando los datos: {e}")
        return gv

gv.update(load_game_data())

# ------------------------
# Clases
# ------------------------
class Particle:
    def __init__(self, pos):
        self.x, self.y = pos
        self.img = imagen_peq.copy()
        self.vx = random.uniform(-4,4)
        self.vy = random.uniform(-4,4)
        self.life = random.randint(100,200)

    def update(self):
        self.vx *= 0.98
        self.vy *= 0.98
        self.x += self.vx
        self.y += self.vy
        self.life -= 2

    def draw(self, surf):
        if self.life > 0:
            tmp = self.img.copy()
            tmp.set_alpha(max(0, int(255 * (self.life / 200)) ))
            surf.blit(tmp, (self.x, self.y))

class Slider:
    def __init__(self, x, y, width, min_val, max_val, initial_val):
        self.rect = pygame.Rect(x, y, width, 20)
        self.min_val = min_val
        self.max_val = max_val
        self.value = initial_val
        self.handle_radius = 10
        self.dragging = False

    def draw(self, surf):
        pygame.draw.line(surf, COLORS['texto'], 
                         (self.rect.x, self.rect.centery), 
                         (self.rect.right, self.rect.centery), 4)
        handle_x = self.rect.x + int((self.value - self.min_val) / (self.max_val - self.min_val) * self.rect.width)
        pygame.draw.circle(surf, COLORS['boton_hover'], 
                           (handle_x, self.rect.centery), self.handle_radius)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if pygame.Rect(self.rect.x - self.handle_radius, self.rect.y,
                           self.rect.width + self.handle_radius*2, self.rect.height).collidepoint(event.pos):
                self.dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            rel_x = max(0, min(event.pos[0] - self.rect.x, self.rect.width))
            self.value = self.min_val + (rel_x / self.rect.width) * (self.max_val - self.min_val)

# ------------------------
# UI y Panels
# ------------------------
def draw_button(surf, rect, text, base_color, hover_color):
    mouse = pygame.mouse.get_pos()
    color = hover_color if rect.collidepoint(mouse) else base_color
    pygame.draw.rect(surf, color, rect, border_radius=8)
    txt = fuente.render(text, True, COLORS['texto'])
    surf.blit(txt, (rect.x + (rect.w - txt.get_width())//2,
                    rect.y + (rect.h - txt.get_height())//2))

panel_x = {'missions': -260, 'stats': ANCHO, 'config': ANCHO}
def slide(val, target, speed=20):
    return val + (target - val) / speed

def draw_missions(surf):
    x = panel_x['missions']
    pygame.draw.rect(surf, COLORS['panel'], (x, 100, 260, 500), border_radius=10)
    pygame.draw.rect(surf, COLORS['texto'], (x, 100, 260, 50), border_radius=10)
    surf.blit(fuente_titulo.render('Misiones', True, COLORS['panel']), (x+10, 105))
    surf.blit(fuente.render(f'Próx Nivel: {gv["nivel"]+1}', True, COLORS['texto']), (x+10, 170))
    if gv['missions']:
        surf.blit(fuente.render(f'Nivel Actual: {gv["nivel"]}', True, COLORS['texto']), (x+10, 210))

def draw_stats(surf):
    x = panel_x['stats']
    pygame.draw.rect(surf, COLORS['panel'], (x-260, 100, 260, 500), border_radius=10)
    pygame.draw.rect(surf, COLORS['texto'], (x-260, 100, 260, 50), border_radius=10)
    surf.blit(fuente_titulo.render('Estadísticas', True, COLORS['panel']), (x-250, 105))
    stats = [
        f'Nivel: {gv["nivel"]}',
        f'Clics: {gv["clics"]}/{gv["umbral"]}',
        f'Monedas: {gv["monedas"]}'
    ]
    for i, s in enumerate(stats):
        surf.blit(fuente.render(s, True, COLORS['texto']), (x-250, 170 + i*40))

def draw_shop(surf):
    items = [
        {'name': 'Activador Automático', 'price': 100, 'key': 'autoclick'},
        {'name': 'Aumento de Clics',    'price': 150, 'key': 'umbral'},
        {'name': 'Multiplicador Mon',   'price': 250, 'key': 'monedas'},
        {'name': 'Aceleración Clics',   'price': 200, 'key': 'velocidad'}
    ]
    pygame.draw.rect(surf, COLORS['panel'], (260, 100, 480, 500), border_radius=10)
    pygame.draw.rect(surf, COLORS['texto'], (260, 100, 480, 50), border_radius=10)
    surf.blit(fuente_titulo.render('Tienda', True, COLORS['panel']),
              (ANCHO//2 - fuente_titulo.size('Tienda')[0]//2, 105))
    for i, item in enumerate(items):
        y = 180 + i*80
        btn = pygame.Rect(280, y, 440, 50)
        label = f"{item['name']} ({item['price']})"
        draw_button(surf, btn, label, COLORS['boton'], COLORS['comprar'])
        if pygame.mouse.get_pressed()[0] and btn.collidepoint(pygame.mouse.get_pos()):
            if gv['monedas'] >= item['price']:
                gv['monedas'] -= item['price']
                if item['key']=='autoclick': gv['autoclick'] = True
                elif item['key']=='umbral': gv['umbral'] = max(1, gv['umbral'] - 5)
                elif item['key']=='monedas': gv['monedas'] += 100
                elif item['key']=='velocidad': gv['last'] = time.time() - 1

def draw_config(surf):
    x = panel_x['config']
    pygame.draw.rect(surf, COLORS['panel'], (x + 260, 100, 480, 500), border_radius=10)
    pygame.draw.rect(surf, COLORS['texto'], (x + 260, 100, 480, 50), border_radius=10)
    surf.blit(fuente_titulo.render('Configuraciones', True, COLORS['panel']),
              (x + ANCHO//2 - fuente_titulo.size('Configuraciones')[0]//2, 105))

    surf.blit(fuente.render(f"Música: {int(gv['music_volume'] * 100)}%", True, COLORS['texto']), (x + 300, 170))
    slider_music.draw(surf)
    surf.blit(fuente.render(f"Sonido: {int(gv['sound_volume'] * 100)}%", True, COLORS['texto']), (x + 300, 250))
    slider_sound.draw(surf)

def draw_extra_panel(surf):
    pygame.draw.rect(surf, COLORS['panel'], (ANCHO - 210, 60, 200, 100), border_radius=10)
    surf.blit(fuente.render("Panel Extra", True, COLORS['texto']), (ANCHO - 200, 75))
    surf.blit(fuente.render("Aquí puedes poner", True, COLORS['texto']), (ANCHO - 200, 105))
    surf.blit(fuente.render("más funciones.", True, COLORS['texto']), (ANCHO - 200, 135))

# ------------------------
# Bucle Principal
# ------------------------
def main():
    global slider_music, slider_sound
    imagen_rect = imagen.get_rect(center=(ANCHO//2, ALTO//2 - 50))
    btn_shop   = pygame.Rect(ANCHO//2 - 50, ALTO - 80, 100, 50)
    btn_miss   = pygame.Rect(10, ALTO - 80, 100, 50)
    btn_stats  = pygame.Rect(ANCHO - 110, ALTO - 80, 100, 50)
    btn_extra  = pygame.Rect(ANCHO - 120, 10, 100, 40)
    btn_config = pygame.Rect(ANCHO - 120, 60, 100, 40)

    slider_music = Slider(300, 200, 400, 0.0, 1.0, gv['music_volume'])
    slider_sound = Slider(300, 280, 400, 0.0, 1.0, gv['sound_volume'])

    while True:
        clock.tick(FPS)
        screen.fill(COLORS['fondo'])

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                save_game_data()
                pygame.quit()
                sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN:
                if imagen_rect.collidepoint(e.pos):
                    gv['clics'] += 1
                    if sonido_clic:
                        sonido_clic.play()
                    for _ in range(30):
                        if len(gv['particles']) < MAX_PARTICLES:
                            gv['particles'].append(Particle(imagen_rect.center))
                    if gv['clics'] >= gv['umbral']:
                        gv['nivel'] += 1
                        gv['clics'] = 0
                        gv['umbral'] += 10
                    if gv['clics'] % 10 == 0:
                        gv['monedas'] += 100
                if btn_shop.collidepoint(e.pos): gv['shop'] = not gv['shop']
                if btn_miss.collidepoint(e.pos): gv['missions'] = not gv['missions']
                if btn_stats.collidepoint(e.pos): gv['stats'] = not gv['stats']
                if btn_extra.collidepoint(e.pos): gv['extra_panel'] = not gv['extra_panel']
                if btn_config.collidepoint(e.pos): gv['config'] = not gv['config']

            if gv['config']:
                slider_music.handle_event(e)
                slider_sound.handle_event(e)

        gv['music_volume'] = slider_music.value
        gv['sound_volume'] = slider_sound.value
        pygame.mixer.music.set_volume(gv['music_volume'])
        if sonido_clic:
            sonido_clic.set_volume(gv['sound_volume'])

        for p in gv['particles'][:]:
            p.update()
            p.draw(screen)
            if p.life <= 0:
                gv['particles'].remove(p)

        screen.blit(imagen, imagen_rect)
        draw_button(screen, btn_shop, 'Tienda', COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_miss, 'Misiones', COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_stats, 'Estadísticas', COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_extra, 'Extra', COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_config, 'Config', COLORS['boton'], COLORS['boton_hover'])

        if gv['shop']: draw_shop(screen)
        if gv['missions']: draw_missions(screen)
        if gv['stats']: draw_stats(screen)
        if gv['config']: draw_config(screen)
        if gv['extra_panel']: draw_extra_panel(screen)

        panel_x['missions'] = slide(panel_x['missions'], 0 if gv['missions'] else -260)
        panel_x['stats']    = slide(panel_x['stats'], ANCHO+260 if not gv['stats'] else ANCHO)
        panel_x['config']   = slide(panel_x['config'], 0 if gv['config'] else ANCHO)

        screen.blit(fuente.render(f"Nivel: {gv['nivel']} | Clics: {gv['clics']}/{gv['umbral']}", True, COLORS['texto']), (20, 20))
        screen.blit(fuente.render(f"Monedas: {gv['monedas']}", True, COLORS['texto']), (ANCHO//2 - 60, ALTO-40))

        pygame.display.flip()

if __name__ == '__main__':
    main() 