import pygame
import sys
import json
import os
import subprocess

# ------------------------
# Configuración Inicial
# ------------------------
pygame.init()
ANCHO, ALTO = 1000, 700
screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Login y Registro - Juego de Clics Profesional")
clock = pygame.time.Clock()
FPS = 60

# ------------------------
# Colores y Fuentes
# ------------------------
COLORS = {
    'fondo': (40, 40, 40),
    'panel': (60, 60, 60),
    'texto': (200, 200, 200),
    'boton': (100, 100, 100),
    'hover': (140, 140, 140),
    'activo': (180, 180, 180)
}
fuente = pygame.font.SysFont('Arial', 32)

# ------------------------
# Archivos
# ------------------------
# Nueva ubicación del archivo JSON
USERS_FILE = os.path.join("data", "usuarios.json")

# Asegurarse de que la carpeta 'data' existe
if not os.path.exists(os.path.join("data")):
    os.makedirs(os.path.join("data"))

def cargar_usuarios():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    return {}

def guardar_usuarios(data):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ------------------------
# Funciones de Interfaz
# ------------------------
def draw_text(surf, text, pos, size=32, center=False):
    font = pygame.font.SysFont('Arial', size)
    txt = font.render(text, True, COLORS['texto'])
    rect = txt.get_rect(center=pos) if center else txt.get_rect(topleft=pos)
    surf.blit(txt, rect)

def draw_input(rect, text, active):
    color = COLORS['activo'] if active else COLORS['panel']
    pygame.draw.rect(screen, color, rect, border_radius=10)
    txt = fuente.render(text, True, COLORS['texto'])
    screen.blit(txt, (rect.x + 10, rect.y + 10))

def draw_button(rect, text, hover):
    color = COLORS['hover'] if hover else COLORS['boton']
    pygame.draw.rect(screen, color, rect, border_radius=12)
    txt = fuente.render(text, True, COLORS['texto'])
    screen.blit(txt, (rect.x + (rect.w - txt.get_width()) // 2, rect.y + (rect.h - txt.get_height()) // 2))

# ------------------------
# Pantalla de Login / Registro
# ------------------------
def login_register_screen():
    username = ''
    password = ''
    modo = 'login'
    campo_activo = None
    mensaje = ''

    input_user = pygame.Rect(400, 250, 200, 50)
    input_pass = pygame.Rect(400, 320, 200, 50)
    btn_login = pygame.Rect(400, 400, 200, 50)
    btn_registro = pygame.Rect(400, 470, 200, 50)

    while True:
        screen.fill(COLORS['fondo'])
        mouse = pygame.mouse.get_pos()
        click = False

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN:
                if input_user.collidepoint(e.pos):
                    campo_activo = 'usuario'
                elif input_pass.collidepoint(e.pos):
                    campo_activo = 'clave'
                elif btn_login.collidepoint(e.pos):
                    modo = 'login'
                    click = True
                elif btn_registro.collidepoint(e.pos):
                    modo = 'registro'
                    click = True
            if e.type == pygame.KEYDOWN and campo_activo:
                if e.key == pygame.K_BACKSPACE:
                    if campo_activo == 'usuario':
                        username = username[:-1]
                    elif campo_activo == 'clave':
                        password = password[:-1]
                else:
                    if campo_activo == 'usuario':
                        username += e.unicode
                    elif campo_activo == 'clave':
                        password += e.unicode

        # Dibujar UI
        draw_text(screen, "Bienvenido", (ANCHO//2, 100), 48, center=True)
        draw_input(input_user, username, campo_activo == 'usuario')
        draw_input(input_pass, '*' * len(password), campo_activo == 'clave')

        draw_button(btn_login, "Iniciar Sesión", btn_login.collidepoint(mouse))
        draw_button(btn_registro, "Registrarse", btn_registro.collidepoint(mouse))

        draw_text(screen, mensaje, (ANCHO//2, 550), 24, center=True)

        if click:
            usuarios = cargar_usuarios()
            if not username or not password:
                mensaje = "Completa todos los campos."
            elif modo == 'login':
                if username in usuarios and usuarios[username]['password'] == password:
                    pygame.quit()
                    # Aquí lanzamos parche.py en segundo plano
                    subprocess.Popen(['python', 'parche.py'])
                    sys.exit()
                else:
                    mensaje = "Usuario o contraseña incorrectos."
            elif modo == 'registro':
                if username in usuarios:
                    mensaje = "Ese usuario ya existe."
                else:
                    usuarios[username] = {"password": password}
                    guardar_usuarios(usuarios)
                    mensaje = "Usuario registrado exitosamente."

        pygame.display.flip()
        clock.tick(FPS)

# ------------------------
# Ejecución Principal
# ------------------------
if __name__ == "__main__":
    login_register_screen()
