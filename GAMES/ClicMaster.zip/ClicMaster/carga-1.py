import pygame
import sys
import time
import subprocess
import os

# Inicializar Pygame
pygame.init()

# Tamaño de la ventana
ANCHO, ALTO = 1000, 700
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Pantalla de Carga")

# Colores grisáceos
FONDO = (50, 50, 50)
BARRA_FONDO = (100, 100, 100)
BARRA_PROGRESO = (170, 170, 170)
TEXTO = (220, 220, 220)

# Fuente
fuente = pygame.font.SysFont("Arial", 36)

def pantalla_carga():
    progreso = 0

    while progreso <= 100:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        ventana.fill(FONDO)

        # Texto de carga
        texto = fuente.render(f"Cargando... {progreso:.0f}%", True, TEXTO)
        ventana.blit(texto, (ANCHO // 2 - texto.get_width() // 2, ALTO // 2 - 80))

        # Barra de carga
        barra_x = 200
        barra_y = ALTO // 2
        barra_ancho = 600
        barra_alto = 40

        pygame.draw.rect(ventana, BARRA_FONDO, (barra_x, barra_y, barra_ancho, barra_alto), border_radius=10)
        pygame.draw.rect(ventana, BARRA_PROGRESO, (barra_x, barra_y, (progreso / 100) * barra_ancho, barra_alto), border_radius=10)

        pygame.display.flip()
        progreso += 0.5
        time.sleep(0.03)

    pygame.quit()

    # Ejecutar app.py desde la misma carpeta (VS 0.0.1/game)
    ruta_app = os.path.join("game.py")
    subprocess.run(["python", ruta_app])

pantalla_carga()
