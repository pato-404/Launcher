import pygame
import sys
import json
import os
import subprocess  # Importamos subprocess para ejecutar el archivo game.py

# ------------------------
# Configuración Inicial
# ------------------------
pygame.init()
pygame.mixer.init()
ANCHO, ALTO = 1000, 700
screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption('Juego de Clics Profesional')
clock = pygame.time.Clock()
FPS = 60

# Función para cargar y cambiar el ícono de la ventana
def cambiar_icono():
    try:
        icono = pygame.image.load('assets/logo.png')  # Cambia el nombre de archivo y ruta si es necesario
        pygame.display.set_icon(icono)
    except Exception as e:
        print(f"Error cargando el ícono: {e}")

# Llamar a la función para cambiar el ícono
cambiar_icono()

# ------------------------
# Colores y Fuentes
# ------------------------
COLORS = {
    'fondo': (50, 50, 50),
    'panel_fondo': (80, 80, 80),  # Gris más claro para el fondo del panel
    'texto': (230, 230, 230),  # Texto claro
    'boton': (100, 100, 100),
    'boton_hover': (150, 150, 150),
    'comprar': (170, 170, 170)
}

try:
    fuente = pygame.font.Font('Roboto-Regular.ttf', 28)
    fuente_titulo = pygame.font.Font('Roboto-Regular.ttf', 42)
except:
    fuente = pygame.font.SysFont('Arial', 28)
    fuente_titulo = pygame.font.SysFont('Arial', 42)

# ------------------------
# Funciones del Menú Inicial
# ------------------------

def draw_button(surf, rect, text, base_color, hover_color):
    mouse = pygame.mouse.get_pos()
    color = hover_color if rect.collidepoint(mouse) else base_color
    pygame.draw.rect(surf, color, rect, border_radius=8)  # Bordes redondeados pero sin borde explícito
    txt = fuente.render(text, True, COLORS['texto'])
    surf.blit(txt, (rect.x + (rect.w - txt.get_width())//2,
                    rect.y + (rect.h - txt.get_height())//2))

# Función para cargar los datos desde el archivo JSON en la carpeta Data/VS 0.0.1
def cargar_datos():
    carpeta = os.path.join("Data")
    if not os.path.exists(carpeta):
        os.makedirs(carpeta)  # Si no existe la carpeta, la crea

    archivo = os.path.join(carpeta, "game_data.json")

    if os.path.exists(archivo):
        with open(archivo, "r") as f:
            datos = json.load(f)
            return {
                "nivel": datos.get("nivel", 1),
                "clics": datos.get("clics", 0),
                "umbral": datos.get("umbral", 30),
                "monedas": datos.get("monedas", 50)
            }
    else:
        return {"nivel": 1, "clics": 0, "umbral": 30, "monedas": 50}

def guardar_datos(nivel, clics, umbral, monedas):
    carpeta = os.path.join("Data")
    if not os.path.exists(carpeta):
        os.makedirs(carpeta)

    archivo = os.path.join(carpeta, "game_data.json")
    datos = {"nivel": nivel, "clics": clics, "umbral": umbral, "monedas": monedas}
    with open(archivo, "w") as f:
        json.dump(datos, f)

def crear_panel_con_bordes_redondeados(tamano, color_fondo, radio_bordes):
    superficie = pygame.Surface(tamano, pygame.SRCALPHA)
    pygame.draw.rect(superficie, color_fondo, superficie.get_rect(), border_radius=radio_bordes)
    return superficie

def mostrar_puntuaciones(datos):
    panel = crear_panel_con_bordes_redondeados((450, 400), COLORS['panel_fondo'], 20)
    
    texto_nivel = fuente.render(f"Nivel: {datos['nivel']}", True, COLORS['texto'])
    texto_clics = fuente.render(f"Clics: {datos['clics']}", True, COLORS['texto'])
    texto_umbral = fuente.render(f"Umbral: {datos['umbral']}", True, COLORS['texto'])
    texto_monedas = fuente.render(f"Monedas: ${datos['monedas']}", True, COLORS['texto'])

    panel.blit(texto_nivel, (30, 30))
    panel.blit(texto_clics, (30, 80))
    panel.blit(texto_umbral, (30, 130))
    panel.blit(texto_monedas, (30, 180))

    btn_cerrar = pygame.Rect(250, 320, 100, 40)
    draw_button(panel, btn_cerrar, "Cerrar", COLORS['boton'], COLORS['boton_hover'])

    screen.blit(panel, (50, ALTO//2 - panel.get_height()//2))
    return btn_cerrar

# ------------------------
# Menú Principal
# ------------------------

def main_menu():
    imagen_izquierda = pygame.image.load('assets/una.png')
    imagen_izquierda = pygame.transform.scale(imagen_izquierda, (150, 150))

    margen_derecho = 100
    btn_start = pygame.Rect(ANCHO - margen_derecho - 200, ALTO//2 - 100, 200, 50)
    btn_options = pygame.Rect(ANCHO - margen_derecho - 200, ALTO//2, 200, 50)
    btn_exit = pygame.Rect(ANCHO - margen_derecho - 200, ALTO//2 + 100, 200, 50)

    btn_scores = pygame.Rect(50, 50, 200, 50)
    btn_help = pygame.Rect(ANCHO - 250, 50, 200, 50)

    datos = cargar_datos()

    puntuaciones_visible = False
    btn_cerrar = None

    while True:
        screen.fill(COLORS['fondo'])
        mouse = pygame.mouse.get_pos()

        imagen_x = ANCHO//2 - imagen_izquierda.get_width() - 50
        screen.blit(imagen_izquierda, (imagen_x, ALTO//2 - imagen_izquierda.get_height()//2))

        if puntuaciones_visible:
            btn_cerrar = mostrar_puntuaciones(datos)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN:
                if btn_start.collidepoint(e.pos):
                    return 'game'
                if btn_options.collidepoint(e.pos):
                    return 'options'
                if btn_exit.collidepoint(e.pos):
                    pygame.quit()
                    sys.exit()
                if btn_scores.collidepoint(e.pos):
                    puntuaciones_visible = not puntuaciones_visible
                if btn_help.collidepoint(e.pos):
                    print("Botón de ayuda presionado")

                if btn_cerrar and btn_cerrar.collidepoint(e.pos):
                    puntuaciones_visible = False

        draw_button(screen, btn_start, "Iniciar Juego", COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_options, "Opciones", COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_exit, "Salir", COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_scores, "Puntuaciones", COLORS['boton'], COLORS['boton_hover'])
        draw_button(screen, btn_help, "Ayuda", COLORS['boton'], COLORS['boton_hover'])

        pygame.display.flip()
        clock.tick(FPS)

# ------------------------
# Función para ejecutar el juego
# ------------------------
def ejecutar_juego():
    archivo_carga1 = os.path.join("carga-1.py")
    
    if os.path.exists(archivo_carga1):
        pygame.quit()  # Cerrar la ventana de Pygame antes de ejecutar el juego
        subprocess.Popen(["python", archivo_carga1])  # Ejecutar el script carga1.py
        sys.exit()  # Terminar el proceso principal de Pygame
    else:
        print("El archivo carga1.py no se encuentra en la ubicación esperada.")

# ------------------------
# Funciones de Opciones
# ------------------------
def options_menu():
    print("Menú de Opciones")

# ------------------------
# Bucle Principal
# ------------------------
def main():
    while True:
        resultado = main_menu()

        if resultado == 'game':
            ejecutar_juego()
        elif resultado == 'options':
            options_menu()

if __name__ == '__main__':
    main()
