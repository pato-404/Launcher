import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import webbrowser

# -------------------------
# Configuración del Launcher
# -------------------------
GAME_FILE = "juego.py"
WEB_URL = "https://tuweb.com"  # Cambia esto a tu sitio si lo deseas

# -------------------------
# Funciones
# -------------------------
def iniciar_juego():
    if os.path.exists(GAME_FILE):
        try:
            subprocess.Popen(["python", GAME_FILE])
            root.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo iniciar el juego:\n{e}")
    else:
        messagebox.showwarning("Archivo no encontrado", f"No se encontró el archivo '{GAME_FILE}'.")

def abrir_web():
    webbrowser.open(WEB_URL)

# -------------------------
# Interfaz Gráfica
# -------------------------
root = tk.Tk()
root.title("Launcher - Juego de Clics Profesional")
root.geometry("400x300")
root.configure(bg="#2b2b2b")
root.resizable(False, False)

# Título
titulo = tk.Label(root, text="🎮 Juego de Clics Profesional", font=("Helvetica", 16, "bold"), fg="white", bg="#2b2b2b")
titulo.pack(pady=20)

# Botón Iniciar
btn_iniciar = tk.Button(root, text="Iniciar Juego", font=("Arial", 14), bg="#4CAF50", fg="white",
                        command=iniciar_juego, width=20, height=2)
btn_iniciar.pack(pady=10)

# Botón Página Web
btn_web = tk.Button(root, text="Visitar Página Web", font=("Arial", 12), bg="#2196F3", fg="white",
                    command=abrir_web)
btn_web.pack(pady=5)

# Información
info = tk.Label(root, text="Versión 1.0\nCreado por TuNombre", font=("Arial", 10), fg="#aaa", bg="#2b2b2b")
info.pack(side="bottom", pady=20)

# Iniciar ventana
root.mainloop()
