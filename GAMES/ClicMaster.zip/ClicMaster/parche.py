import subprocess
import sys

def ejecutar_script(script_name):
    """Ejecuta un script y espera a que termine."""
    try:
        print(f"Ejecutando {script_name}...")
        
        # Ejecutar el script en segundo plano
        proceso = subprocess.Popen(['python', script_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Esperar a que el script termine
        stdout, stderr = proceso.communicate()

        # Imprimir cualquier salida del script
        if stdout:
            print(stdout.decode())
        if stderr:
            print(stderr.decode())

        print(f"{script_name} ha terminado de ejecutarse.")

    except Exception as e:
        print(f"Error al ejecutar {script_name}: {e}")

def main():
    """Ejecuta los scripts en secuencia."""
    ejecutar_script("carga.py")      # Ejecutar carga.py
    ejecutar_script("panel.py")      # Ejecutar panel.py
    ejecutar_script("carga-1.py")    # Ejecutar carga-1.py
    ejecutar_script("game.py")       # Ejecutar game.py

    print("Todos los scripts han terminado de ejecutarse. El programa se cerrará.")
    sys.exit()  # Finaliza el proceso

if __name__ == "__main__":
    main()
